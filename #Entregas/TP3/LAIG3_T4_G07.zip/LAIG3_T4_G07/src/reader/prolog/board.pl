boardDefault(	[[s, s, s, s, s ],
       [s, s, s, s, s, s ],
      [s, s, s, s, s, s, s ],
    [s, s, s, s, s, s, s, s ],
   [s, s, s, s, s, s, s, s, s ],
    [s, s, s, s, s, s, s, s ],
      [s, s, s, s, s, s, s ],
        [s, s, s, s, s, s ],
          [s, s, s, s, s ]]).

board(	[[s, s, s, s, s ],
       [s, s, s, s, s, s ],
      [s, s, s, s, s, s, s ],
    [s, s, s, s, s, s, s, s ],
   [s, s, s, s, s, s, s, s, s ],
    [s, s, s, s, s, s, s, s ],
      [s, s, s, s, s, s, s ],
        [s, s, s, s, s, s ],
          [s, s, s, s, s ]]).