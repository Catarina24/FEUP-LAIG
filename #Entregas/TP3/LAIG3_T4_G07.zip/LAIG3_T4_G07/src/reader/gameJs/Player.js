/**
* Player
* @constructor
*/

function Player(name, piece){
    
    this.name = name;
    this.piece = piece;
    
}

Player.prototype.constructor=Player;

