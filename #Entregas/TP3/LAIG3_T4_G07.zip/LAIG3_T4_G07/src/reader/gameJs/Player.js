/**
* Player
* @constructor
*/

function Player(name, piece){
    
    this.name = name;
    this.piece = piece;
    this.human = true;
}

Player.prototype.constructor=Player;

